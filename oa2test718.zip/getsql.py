# -*- coding: UTF-8 -*-
import rdexcel
import  MySQLdb
import sys
default_encoding = 'utf-8'
if sys.getdefaultencoding() != default_encoding:
    reload(sys)
    sys.setdefaultencoding(default_encoding)
class sql():

    @classmethod
    def getsqldata(self):

        db = MySQLdb.connect("119.23.12.94", "root", "root", "worklist", charset='utf8')
        # 使用cursor()方法获取操作游标
        # cursor = db.cursor()
        # 使用 fetchone() 方法获取一条数据
        cursor = db.cursor()
        a = rdexcel.readexcel()
        listdata1 = a.excel_table_byindex("add1.xlsx", 0, 0)
        id = []
        taskId=[]
        for i in range(0, len(listdata1)):
            na1 = listdata1[i]['loanerCardId']
            sql = "SELECT loan_requests.id,loan_requests.customer_name,flow_run_task.id FROM loan_requests,flow_run_task where loan_requests.credential='%s' and loan_requests.id=flow_run_task.business_id ORDER BY  flow_run_task.create_time deSC" % na1
            cursor.execute(sql)
            results = cursor.fetchall()
            # print type(results)
            # print( len(results))
            # print results
            # fields = cursor.description
            # workbook = xlwt.Workbook()
            # sheet = workbook.add_sheet('table_message',cell_overwrite_ok=True)
            # fname = []
            # print results
            for row in results[0:1]:
                # print(type(id))
                # row1=int(row[0])
                # print(row1)
                id.append(row[0])
                # customer_name = row[1]
                taskId.append(row[2])
                # print(type(id))
                # print len(id),

        db.close()
        return id,taskId



    @classmethod
    def GetName(self):

        db = MySQLdb.connect("119.23.12.94", "root", "root", "worklist", charset='utf8')
        cursor = db.cursor()
        a = rdexcel.readexcel()
        listdata1 = a.excel_table_byindex("add1.xlsx", 0, 0)
        customer_name1 = []
        for i in range(0, len(listdata1)):
            na1 = listdata1[i]['loanerCardId']
            sql="select customer_name from loan_requests where credential='%s'ORDER BY create_time desc"% na1
            cursor.execute(sql)
            results = cursor.fetchall()
            for row in results:
                # print(row[0])
                customer_name1.append(row[0])
                # print customer_name1[i]
        db.close()
        return customer_name1

    @classmethod
    def GetZhengxinID(self):

        db = MySQLdb.connect("119.23.12.94", "root", "root", "worklist", charset='utf8')
        # 使用cursor()方法获取操作游标
        # cursor = db.cursor()
        # 使用 fetchone() 方法获取一条数据
        cursor = db.cursor()
        a = rdexcel.readexcel()
        listdata1 = a.excel_table_byindex("add1.xlsx", 0, 0)
        id = []
        taskId=[]
        for i in range(0, len(listdata1)):
            na1 = listdata1[i]['loanerCardId']
            sql = "SELECT loan_requests.id,loan_requests.customer_name,flow_run_task.id FROM loan_requests,flow_run_task where loan_requests.credential='%s' and loan_requests.id=flow_run_task.business_id  and flow_run_task.segment_name='征信后补充资料'  ORDER BY  loan_requests.create_time DESC" % na1
            cursor.execute(sql)
            results = cursor.fetchall()
            for row in results[0:1]:
                id.append(row[0])
                taskId.append(row[2])
        db.close()
        return id,taskId

    @classmethod
    def GetCheJiaPingGuID(self):
        db = MySQLdb.connect("119.23.12.94", "root", "root", "worklist", charset='utf8')
        # 使用cursor()方法获取操作游标
        # cursor = db.cursor()
        # 使用 fetchone() 方法获取一条数据
        cursor = db.cursor()
        a = rdexcel.readexcel()
        listdata1 = a.excel_table_byindex("add1.xlsx", 0, 0)
        id = []
        taskId = []
        for i in range(0, len(listdata1)):
            na1 = listdata1[i]['loanerCardId']
            sql = "SELECT loan_requests.id,loan_requests.customer_name,flow_run_task.id FROM loan_requests,flow_run_task where loan_requests.credential='%s' and loan_requests.id=flow_run_task.business_id  and flow_run_task.segment_name='真实车价评估'  ORDER BY  loan_requests.create_time DESC" % na1
            cursor.execute(sql)
            results = cursor.fetchall()
            # print type(results)
            # print( len(results))
            # print results
            # fields = cursor.description
            # workbook = xlwt.Workbook()
            # sheet = workbook.add_sheet('table_message',cell_overwrite_ok=True)
            # fname = []

            for row in results[0:1]:
                # print(type(id))
                # row1=int(row[0])
                # print(row1)
                id.append(row[0])
                # customer_name = row[1]
                taskId.append(row[2])
                # print(type(id))
                # print len(id),
        # print id
        # print taskId
        db.close()
        return id, taskId


    @classmethod
    def GetZhengxinReprot(self):

        db = MySQLdb.connect("119.23.12.94", "root", "root", "worklist", charset='utf8')
        # 使用cursor()方法获取操作游标
        # cursor = db.cursor()
        # 使用 fetchone() 方法获取一条数据
        cursor = db.cursor()
        a = rdexcel.readexcel()
        listdata1 = a.excel_table_byindex("add1.xlsx", 0, 0)
        id = []
        process_Id = []
        for i in range(0, len(listdata1)):
            na1 = listdata1[i]['loanerCardId']
            sql = "SELECT loan_requests.id ,bank_credit_report.id as id2 FROM loan_requests,bank_credit_report WHERE loan_requests.credential='%s' and loan_requests.process_id=bank_credit_report.process_id ORDER BY   loan_requests.create_time desc" % na1
            cursor.execute(sql)
            results = cursor.fetchall()
            for row in results[0:1]:
                # print(type(id)
                row1=int(row[0])
                id.append(row[0])
                # customer_name = row[1]
                process_Id.append(row[1])
                # print(type(id))
        db.close()
        return id, process_Id


    @classmethod
    def GetShenheHouBuChongID(self):

        db = MySQLdb.connect("119.23.12.94", "root", "root", "worklist", charset='utf8')
        # 使用cursor()方法获取操作游标
        # cursor = db.cursor()
        # 使用 fetchone() 方法获取一条数据
        cursor = db.cursor()
        a = rdexcel.readexcel()
        listdata1 = a.excel_table_byindex("add1.xlsx", 0, 0)
        id = []
        taskId=[]
        for i in range(0, len(listdata1)):
            na1 = listdata1[i]['loanerCardId']
            sql = "SELECT loan_requests.id,loan_requests.customer_name,flow_run_task.id FROM loan_requests,flow_run_task where loan_requests.credential='%s' and loan_requests.id=flow_run_task.business_id  and flow_run_task.segment_name='审核后补充资料'  ORDER BY  loan_requests.create_time DESC" % na1
            cursor.execute(sql)
            results = cursor.fetchall()
            for row in results[0:1]:
                id.append(row[0])
                taskId.append(row[2])
        db.close()
        return id,taskId


    @classmethod
    def GetZhiZhiZiLiaoID(self):
        db = MySQLdb.connect("119.23.12.94", "root", "root", "worklist", charset='utf8')
        # 使用cursor()方法获取操作游标
        # cursor = db.cursor()
        # 使用 fetchone() 方法获取一条数据
        cursor = db.cursor()
        a = rdexcel.readexcel()
        listdata1 = a.excel_table_byindex("add1.xlsx", 0, 0)
        id = []
        taskId = []
        for i in range(0, len(listdata1)):
            na1 = listdata1[i]['loanerCardId']
            sql = "SELECT loan_requests.id,loan_requests.customer_name,flow_run_task.id FROM loan_requests,flow_run_task where loan_requests.credential='%s' and loan_requests.id=flow_run_task.business_id  and flow_run_task.segment_name='纸质资料确认'  ORDER BY  loan_requests.create_time DESC" % na1
            cursor.execute(sql)
            results = cursor.fetchall()
            for row in results[0:1]:
                id.append(row[0])
                taskId.append(row[2])
        db.close()
        return id, taskId

    @classmethod
    def GetCheLiangPingGuBaoGaoID(self):
        db = MySQLdb.connect("119.23.12.94", "root", "root", "worklist", charset='utf8')
        # 使用cursor()方法获取操作游标
        # cursor = db.cursor()
        # 使用 fetchone() 方法获取一条数据
        cursor = db.cursor()
        a = rdexcel.readexcel()
        listdata1 = a.excel_table_byindex("add1.xlsx", 0, 0)
        id = []
        taskId = []
        for i in range(0, len(listdata1)):
            na1 = listdata1[i]['loanerCardId']
            sql = "SELECT loan_requests.id,loan_requests.customer_name,flow_run_task.id FROM loan_requests,flow_run_task where loan_requests.credential='%s' and loan_requests.id=flow_run_task.business_id  and flow_run_task.segment_name='车辆评估报告'  ORDER BY  loan_requests.create_time DESC" % na1
            cursor.execute(sql)
            results = cursor.fetchall()
            for row in results[0:1]:
                id.append(row[0])
                taskId.append(row[2])
        # print(taskId)
        db.close()
        return id, taskId


    @classmethod
    def ChuShenID(self):
        db = MySQLdb.connect("119.23.12.94", "root", "root", "worklist", charset='utf8')
        # 使用cursor()方法获取操作游标
        # cursor = db.cursor()
        # 使用 fetchone() 方法获取一条数据
        cursor = db.cursor()
        a = rdexcel.readexcel()
        listdata1 = a.excel_table_byindex("add1.xlsx", 0, 0)
        id = []
        taskId = []
        for i in range(0, len(listdata1)):
            na1 = listdata1[i]['loanerCardId']
            sql = "SELECT loan_requests.id,loan_requests.customer_name,flow_run_task.id FROM loan_requests,flow_run_task where loan_requests.credential='%s' and loan_requests.id=flow_run_task.business_id  and flow_run_task.segment_name='初审'  ORDER BY  loan_requests.create_time DESC" % na1
            cursor.execute(sql)
            results = cursor.fetchall()
            for row in results[0:1]:
                id.append(row[0])
                taskId.append(row[2])
        # print(taskId)
        db.close()
        return id, taskId

    @classmethod
    def AddCaiWu(self):
        db = MySQLdb.connect("119.23.12.94", "root", "root", "worklist", charset='utf8')
        # 使用cursor()方法获取操作游标
        # cursor = db.cursor()
        # 使用 fetchone() 方法获取一条数据
        cursor = db.cursor()
        a = rdexcel.readexcel()
        listdata1 = a.excel_table_byindex("add1.xlsx", 0, 0)
        id = []
        taskId = []
        for i in range(0, len(listdata1)):
            na1 = listdata1[i]['loanerCardId']
            sql = "SELECT loan_requests.id,loan_requests.customer_name,flow_run_task.id FROM loan_requests,flow_run_task where loan_requests.credential='%s' and loan_requests.id=flow_run_task.business_id  and flow_run_task.segment_name='添加财务信息'  ORDER BY  loan_requests.create_time DESC" % na1
            cursor.execute(sql)
            results = cursor.fetchall()
            for row in results[0:1]:
                id.append(row[0])
                taskId.append(row[2])
        # print(taskId)
        db.close()
        return id, taskId

    @classmethod
    def CaiWuSheHe(self):
        db = MySQLdb.connect("119.23.12.94", "root", "root", "worklist", charset='utf8')
        # 使用cursor()方法获取操作游标
        # cursor = db.cursor()
        # 使用 fetchone() 方法获取一条数据
        cursor = db.cursor()
        a = rdexcel.readexcel()
        listdata1 = a.excel_table_byindex("add1.xlsx", 0, 0)
        id = []
        taskId = []
        for i in range(0, len(listdata1)):
            na1 = listdata1[i]['loanerCardId']
            sql = "SELECT loan_requests.id,loan_requests.customer_name,flow_run_task.id FROM loan_requests,flow_run_task where loan_requests.credential='%s' and loan_requests.id=flow_run_task.business_id  and flow_run_task.segment_name='财务审核'  ORDER BY  loan_requests.create_time DESC" % na1
            cursor.execute(sql)
            results = cursor.fetchall()
            for row in results[0:1]:
                id.append(row[0])
                taskId.append(row[2])
        # print(taskId)
        db.close()
        return id, taskId

    @classmethod
    def ChuNaDianKuan(self):
        db = MySQLdb.connect("119.23.12.94", "root", "root", "worklist", charset='utf8')
        # 使用cursor()方法获取操作游标
        # cursor = db.cursor()
        # 使用 fetchone() 方法获取一条数据
        cursor = db.cursor()
        a = rdexcel.readexcel()
        listdata1 = a.excel_table_byindex("add1.xlsx", 0, 0)
        id = []
        taskId = []
        for i in range(0, len(listdata1)):
            na1 = listdata1[i]['loanerCardId']
            sql = "SELECT loan_requests.id,loan_requests.customer_name,flow_run_task.id FROM loan_requests,flow_run_task where loan_requests.credential='%s' and loan_requests.id=flow_run_task.business_id  and flow_run_task.segment_name='出纳垫款'  ORDER BY  loan_requests.create_time DESC" % na1
            cursor.execute(sql)
            results = cursor.fetchall()
            for row in results[0:1]:
                id.append(row[0])
                taskId.append(row[2])
        # print(taskId)
        db.close()
        return id, taskId


    @classmethod
    def StartZhengXin(self):
        db = MySQLdb.connect("119.23.12.94", "root", "root", "worklist", charset='utf8')
        # 使用cursor()方法获取操作游标
        # cursor = db.cursor()
        # 使用 fetchone() 方法获取一条数据
        cursor = db.cursor()
        a = rdexcel.readexcel()
        listdata1 = a.excel_table_byindex("add1.xlsx", 0, 0)
        id = []
        taskId = []
        for i in range(0, len(listdata1)):
            na1 = listdata1[i]['loanerCardId']
            sql = "SELECT a.id  from loan_requests a,flow_instance b where a.id=b.business_id and a.credential='%s' and b.flow_state ='2'  " % na1
            cursor.execute(sql)
            results = cursor.fetchall()
            for row in results[0:1]:
                id.append(row[0])

        # print(process_id)
        db.close()
        return id

a=sql.getsqldata()