# -*- coding: UTF-8 -*-
import rdexcel
import requests
import json
import weblogin
import  MySQLdb
import getsql
import api
import sys

default_encoding = 'utf-8'
if sys.getdefaultencoding() != default_encoding:
    reload(sys)
    sys.setdefaultencoding(default_encoding)
class zhuhang():

    @classmethod
    def ZhuHangDY(self):
        token = weblogin.gettoken.token()
        taskId1 = getsql.sql.getsqldata()[1]
        # print(taskId1)

        for i in range(0,len(taskId1)):
            taskId=taskId1[i]
            headers = api.API.SetHeaders()
            payload1={
                 "data": {
                     "moduleCode": "creditPrint",
                        "taskId": taskId
                     },
                    "ext": "string",
                    "header": {
                     "app": "string",
                     "gps": "string",
                      "os": "string",
                     "token": token,
                     "ver": "string"
      }
    }
            url3 = api.API.SetUrl()+"work/receiveTask"
            data = json.dumps(payload1)
            response = requests.request("POST", url3, data=data, headers=headers)

            response.text1 = json.loads(response.text)
            customer = getsql.sql.GetName()[i]
            print ("主贷人:" + customer + "  驻行打印领取:" + response.text1["header"]["msg"][0])
            payload2={
                      "data": {
                        "completed": "true",
                        "creditMeterial": [
                            {
                                "code": "IDF",
                                "name": "........................",
                                "meterialType": 2,
                                "enableFlag": 0,
                                "remark": "null",
                                "existFlag": 0,
                                "urlList": [
                                    "http://hschefu-ivt.oss-cn-shenzhen.aliyuncs.com/res/erp/510104198806031672/IDF18ca204cbcc227b20d836d55059ab6b8.jpg"],
                                "serialNum": 10,
                                "linkType": 1,
                                "updateFlag": "null",
                                "optionalFlag": 0
                            }, {
                                "code": "IDB",
                                "name": "........................",
                                "meterialType": 2,
                                "enableFlag": 0,
                                "remark": "null",
                                "existFlag": 0,
                                "urlList": [
                                    "http://hschefu-ivt.oss-cn-shenzhen.aliyuncs.com/res/erp/510104198806031672/IDBe423f7dfa12298159d05816a34efe81f.jpg"],
                                "serialNum": 20,
                                "linkType": 1,
                                "updateFlag": "null",
                                "optionalFlag": 0
                            }, {
                                "code": "LE",
                                "name": "..............................",
                                "meterialType": 2,
                                "enableFlag": 0,
                                "remark": "null",
                                "existFlag": 0,
                                "urlList": [
                                    "http://hschefu-ivt.oss-cn-shenzhen.aliyuncs.com/res/erp/510104198806031672/LE58583af34c31202acc9bf3a3709bad08.jpg"],
                                "serialNum": 30,
                                "linkType": 1,
                                "updateFlag": "null",
                                "optionalFlag": 0
                            }, {
                                "code": "AP",
                                "name": "........................",
                                "meterialType": 2,
                                "enableFlag": 0,
                                "remark": "null",
                                "existFlag": 0,
                                "urlList": [
                                    "http://hschefu-ivt.oss-cn-shenzhen.aliyuncs.com/res/erp/510104198806031672/AP5b9708d50f9f8d8b1b2ef0cb82785e20.jpg"],
                                "serialNum": 40,
                                "linkType": 1,
                                "updateFlag": "null",
                                "optionalFlag": 0
                            },


                          {
                            "code": "string",
                            "enableFlag": 0,
                            "existFlag": 0,
                            "linkType": 0,
                            "meterialType": 0,
                            "name": "string",
                            "optionalFlag": 0,
                            "remark": "string",
                            "serialNum": 0,
                            "updateFlag": 0,
                            "urlList": [
                              "string"
                            ]
                          }
                        ],
                        "handleRemark": "string",
                        "push": "false",
                        "result": 1,
                        "segmentNo": 11,
                        "taskId": taskId,
                        "toUserId": 338
                      },
                      "ext": "string",
                      "header": {
                        "app": "string",
                        "gps": "string",
                        "os": "string",
                        "token": token,
                        "ver": "string"
                      }
                        }
            url4 = api.API.SetUrl()+"work/handle/creditPrint"
            data = json.dumps(payload2)
            response = requests.request("POST", url4, data=data, headers=headers)
            response.text1 = json.loads(response.text)
            customer = getsql.sql.GetName()[i]
            print ("主贷人:" + customer + "  驻行打印指派:" + response.text1["header"]["msg"][0])
    @classmethod
    def songshen(self):

        token = weblogin.gettoken.ZhuHangSStoken()
        id2=getsql.sql.getsqldata()[0]
        taskId1 = getsql.sql.getsqldata()[1]
        # token = weblogin.gettoken.token()
        process_id1 = getsql.sql.GetZhengxinReprot()[1]
        id1 = getsql.sql.GetZhengxinReprot()[0]
        # print(taskId1)

        for i in range(0,len(taskId1)):
            taskId=taskId1[i]
            headers = api.API.SetHeaders()
            url1 = api.API.SetUrl()+"work/receiveTask"
            payload1 = {
                      "data": {
                        "moduleCode": "credit",
                        "taskId": taskId
                      },

                      "ext": "string",
                      "header": {
                        "app": "string",
                        "gps": "string",
                        "os": "string",
                        "token": token,
                        "ver": "string"
                      }
                    }
            data = json.dumps(payload1)
            response = requests.request("POST", url1, data=data, headers=headers)
            #领取待办
            url2 = api.API.SetUrl()+"work/handle/credit"
            response.text1 = json.loads(response.text)
            customer = getsql.sql.GetName()[i]
            # print ("主贷人:"+customer+"  驻行领取:"+response.text1["header"]["msg"][0])

            # id1=id2[i]
            # print token
            # testdata={
            #     "data": id1,
            #     "header": {
            #         "token": token
            #     }
            # }
            # url4 = api.API.SetUrl() + "work/extra/queryBankCreditReport"
            # data = json.dumps(testdata)
            # response3 = requests.request("POST", url4, data=data, headers=headers)
            # response3.text1 = json.loads(response3.text)
            # customer = getsql.sql.GetName()[i]
            # print ("主贷人:" + customer + "  编辑征信报告:" + response3.text1["header"]["msg"][0])
            #
            # id = id1[i]
            # process_id = process_id1[i]
            # headers = api.API.SetHeaders()
            # url3 = api.API.SetUrl() + "work/extra/updateBankCreditReport"
            # process_id=process_id1[i]
            # payload1 = {
            #     "data": {
            #         "id": process_id,
            #         "requestId": id,
            #         "custName": "测试挨打吧1",
            #         "custIdcard": "142422198903030972",
            #         "trialPass": "1",
            #         "married": "1",
            #         "education": "大专",
            #         "couple": None,
            #         "baihu": "1",
            #         "jinru": "0",
            #         "yuqiCount": "0",
            #         "accountDetail": "1",
            #         "waibuqizha": "0",
            #         "has14": "0",
            #         "greyList": "0",
            #         "guaranteeCount": "1",
            #         "guaranteeAmount": "1",
            #         "guaranteeStatus": "1是",
            #         "creditCardCount": "2",
            #         "usedMoney": None,
            #         "overdue12": "1",
            #         "overdue24": "0",
            #         "yearA": "2018",
            #         "monthA": "06",
            #         "nameA": "111111",
            #         "amountA": "111111",
            #         "amountYueA": "111111",
            #         "loanFangshiA": "111111",
            #         "loanQishuA": "111111",
            #         "yearB": "2018",
            #         "monthB": "05",
            #         "nameB": "1111111",
            #         "amountB": "1111111",
            #         "amountYueB": "1111111",
            #         "loanFangshiB": "未知",
            #         "loanQishuB": "2",
            #         "yearC": "2018",
            #         "monthC": "04",
            #         "nameC": "222222",
            #         "amountC": "222222",
            #         "amountYueC": "222222",
            #         "loanFangshiC": "未知",
            #         "loanQishuC": "2",
            #         "ghCreditLine": "1",
            #         "ghCardCount": "1",
            #         "allLoanTotal": "11111",
            #         "allLoanAmount": "111111",
            #         "repaymentTypeA": "111111",
            #         "repaymentMonthA": "111111",
            #         "loanOverdueMonthA": "06",
            #         "currentOverdueAmountA": "111111",
            #         "currentStatusA": "逾期",
            #         "repaymentTypeC": "2",
            #         "repaymentMonthC": "222222",
            #         "loanOverdueMonthC": "3",
            #         "currentOverdueAmountC": "222222",
            #         "currentStatusC": "未知",
            #         "repaymentTypeB": "12",
            #         "repaymentMonthB": "6789",
            #         "loanOverdueMonthB": "1",
            #         "currentOverdueAmountB": "222222",
            #         "currentStatusB": "未知",
            #         "creditCardOrg": "1",
            #         "accountCount": None,
            #         "creditLine": "100000",
            #         "usedLine": "10000",
            #         "loanYearA": "2018",
            #         "loanMonthA": "3",
            #         "loanCreditLineA": "100000",
            #         "loanUsedLineA": "20000",
            #         "overdueYearMonthA": "1",
            #         "overdueAmountA": "70000",
            #         "overdueStatusA": "未知",
            #         "loanYearB": "2018",
            #         "loanMonthB": "4",
            #         "loanCreditLineB": "100000",
            #         "loanUsedLineB": "40000",
            #         "overdueYearMonthB": "2",
            #         "overdueAmountB": "60000",
            #         "overdueStatusB": "未知",
            #         "queryName": "向进",
            #         "queryTime": "2018-05-27 19:10:37",
            #         "remark": "测试征信",
            #         "creditType": 0,
            #         "changeCompany": "测试公司名称123213asdadasd",
            #         "riskRankFive": "0",
            #         "queryCountThree": "1",
            #         "loanerFlag": "1"
            #     },
            #     "header": {
            #         "app": " ",
            #         "gps": " ",
            #         "os": " ",
            #         "ver": " ",
            #         "token": token
            #     }
            # }
            # data = json.dumps(payload1)
            # response3 = requests.request("POST", url3, data=data, headers=headers)
            # response3.text1 = json.loads(response3.text)
            # customer = getsql.sql.GetName()[i]
            # print ("主贷人:" + customer + "  编辑征信报告:" + response3.text1["header"]["msg"][0])








            payload2 = {
                          "data": {
                            "completed": "true",
                            "creditMeterial": [{
                              "code": "IDF",
                              "name": "........................",
                              "meterialType": 2,
                              "enableFlag": 0,
                              "remark": "null",
                              "existFlag": 0,
                              "urlList": ["http://hschefu-ivt.oss-cn-shenzhen.aliyuncs.com/res/erp/510104198806031672/IDF18ca204cbcc227b20d836d55059ab6b8.jpg"],
                              "serialNum": 10,
                              "linkType": 1,
                              "updateFlag": "null",
                              "optionalFlag": 0
                            }, {
                              "code": "IDB",
                              "name": "........................",
                              "meterialType": 2,
                              "enableFlag": 0,
                              "remark": "null",
                              "existFlag": 0,
                              "urlList": ["http://hschefu-ivt.oss-cn-shenzhen.aliyuncs.com/res/erp/510104198806031672/IDBe423f7dfa12298159d05816a34efe81f.jpg"],
                              "serialNum": 20,
                              "linkType": 1,
                              "updateFlag": "null",
                              "optionalFlag": 0
                            }, {
                              "code": "LE",
                              "name": "..............................",
                              "meterialType": 2,
                              "enableFlag": 0,
                              "remark": "null",
                              "existFlag": 0,
                              "urlList": ["http://hschefu-ivt.oss-cn-shenzhen.aliyuncs.com/res/erp/510104198806031672/LE58583af34c31202acc9bf3a3709bad08.jpg"],
                              "serialNum": 30,
                              "linkType": 1,
                              "updateFlag": "null",
                              "optionalFlag": 0
                            }, {
                              "code": "AP",
                              "name": "........................",
                              "meterialType": 2,
                              "enableFlag": 0,
                              "remark": "null",
                              "existFlag": 0,
                              "urlList": ["http://hschefu-ivt.oss-cn-shenzhen.aliyuncs.com/res/erp/510104198806031672/AP5b9708d50f9f8d8b1b2ef0cb82785e20.jpg"],
                              "serialNum": 40,
                              "linkType": 1,
                              "updateFlag": "null",
                              "optionalFlag": 0
                            },
                              {
                                "code": "IDF",
                                "enableFlag": 0,
                                "existFlag": 0,
                                "linkType": 1,
                                "meterialType": 0,
                                "name": "string",
                                "optionalFlag": 0,
                                "remark": "null",
                                "serialNum": 10,
                                "updateFlag": 0,
                                "urlList": [
                                  "string"
                                ]
                              }
                            ],
                            "handleRemark": "string",
                            "push": "true",
                            "result": 1,

                            "taskId": taskId
                          },
                          "ext": "string",
                          "header": {
                            "app": "string",
                            "gps": "string",
                            "os": "string",
                            "token": token,
                            "ver": "string"
                          }
                        }
            data = json.dumps(payload2)
            response2=requests.request("POST", url2, data=data, headers=headers)
            response.text1 = json.loads(response2.text)
            customer = getsql.sql.GetName()[i]
            print ("主贷人:"+customer+ "  驻行审核:"+response.text1["header"]["msg"][0])
            # print "id=%s,customer_name=%s,age=%s,credential=%s," % \
            #       (id, customer_name, age, credential,)
    # @classmethod
    # def ZhengXinReport(self):
    #     token = weblogin.gettoken.token()
    #     process_id1 = getsql.sql.GetZhengxinReprot()[1]
    #     id1=getsql.sql.GetZhengxinReprot()[0]
    #     for i in range(0, len(process_id1)):
    #         id=id1[i]
    #         process_id=process_id1[i]
    #         headers = api.API.SetHeaders()
    #         url1 = api.API.SetUrl() + "api/work/extra/updateBankCreditReport"
    #
    #         payload1 ={
    #             "data": {
    #                 "id": process_id,
    #                 "requestId": id,
    #                 "custName": "测试挨打吧1",
    #                 "custIdcard": "142422198903030972",
    #                 "trialPass": "1",
    #                 "married": "1",
    #                 "education": "大专",
    #                 "couple": None,
    #                 "baihu": "1",
    #                 "jinru": "0",
    #                 "yuqiCount": "0",
    #                 "accountDetail": "1",
    #                 "waibuqizha": "0",
    #                 "has14": "0",
    #                 "greyList": "0",
    #                 "guaranteeCount": "1",
    #                 "guaranteeAmount": "1",
    #                 "guaranteeStatus": "1是",
    #                 "creditCardCount": "2",
    #                 "usedMoney": None,
    #                 "overdue12": "1",
    #                 "overdue24": "0",
    #                 "yearA": "2018",
    #                 "monthA": "06",
    #                 "nameA": "111111",
    #                 "amountA": "111111",
    #                 "amountYueA": "111111",
    #                 "loanFangshiA": "111111",
    #                 "loanQishuA": "111111",
    #                 "yearB": "2018",
    #                 "monthB": "05",
    #                 "nameB": "1111111",
    #                 "amountB": "1111111",
    #                 "amountYueB": "1111111",
    #                 "loanFangshiB": "未知",
    #                 "loanQishuB": "2",
    #                 "yearC": "2018",
    #                 "monthC": "04",
    #                 "nameC": "222222",
    #                 "amountC": "222222",
    #                 "amountYueC": "222222",
    #                 "loanFangshiC": "未知",
    #                 "loanQishuC": "2",
    #                 "ghCreditLine": "1",
    #                 "ghCardCount": "1",
    #                 "allLoanTotal": "11111",
    #                 "allLoanAmount": "111111",
    #                 "repaymentTypeA": "111111",
    #                 "repaymentMonthA": "111111",
    #                 "loanOverdueMonthA": "06",
    #                 "currentOverdueAmountA": "111111",
    #                 "currentStatusA": "逾期",
    #                 "repaymentTypeC": "2",
    #                 "repaymentMonthC": "222222",
    #                 "loanOverdueMonthC": "3",
    #                 "currentOverdueAmountC": "222222",
    #                 "currentStatusC": "未知",
    #                 "repaymentTypeB": "12",
    #                 "repaymentMonthB": "6789",
    #                 "loanOverdueMonthB": "1",
    #                 "currentOverdueAmountB": "222222",
    #                 "currentStatusB": "未知",
    #                 "creditCardOrg": "1",
    #                 "accountCount": None,
    #                 "creditLine": "100000",
    #                 "usedLine": "10000",
    #                 "loanYearA": "2018",
    #                 "loanMonthA": "3",
    #                 "loanCreditLineA": "100000",
    #                 "loanUsedLineA": "20000",
    #                 "overdueYearMonthA": "1",
    #                 "overdueAmountA": "70000",
    #                 "overdueStatusA": "未知",
    #                 "loanYearB": "2018",
    #                 "loanMonthB": "4",
    #                 "loanCreditLineB": "100000",
    #                 "loanUsedLineB": "40000",
    #                 "overdueYearMonthB": "2",
    #                 "overdueAmountB": "60000",
    #                 "overdueStatusB": "未知",
    #                 "queryName": "向进",
    #                 "queryTime": "2018-05-27 19:10:37",
    #                 "remark": "测试征信",
    #                 "creditType": 0,
    #                 "changeCompany": "测试公司名称123213asdadasd",
    #                 "riskRankFive": "0",
    #                 "queryCountThree": "1",
    #                 "loanerFlag": "1"
    #             },
    #             "header": {
    #                 "app": " ",
    #                 "gps": " ",
    #                 "os": " ",
    #                 "ver": " ",
    #                 "token": token
    #             }
    #         }
    #         data = json.dumps(payload1)
    #         response2=requests.request("POST", url1, data=data, headers=headers)
    #         response2.text1 = json.loads(response2.text)
    #         customer = getsql.sql.GetName()[i]
    #         print ("主贷人:"+customer+ "  编辑征信报告:"+response2.text1["header"]["msg"][0])


# a=zhuhang.songshen()
