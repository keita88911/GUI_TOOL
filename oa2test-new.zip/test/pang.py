
curren_users=['laoli','erdai','wangjihao','hewen','admin','ceshi']
new_users=['erdai','WangEr','LISI','HEWEN','CeShi','HHH']

for user in new_users:
    for curren in curren_users:
        if user.upper()==curren:
            print('Sorry,'+user+' is used,you have to update user!')
        else:
            print('Ok,'+user+' can use!')