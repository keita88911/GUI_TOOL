#!/usr/bin/env python
# -*- coding:utf-8 -*-
a = ((1, '惠商OA', 0, 1),
     (2, '登录接口', 1, 2),
     (3, '审核相关', 1, 2),
     (4, '财务相关', 1, 2),
     (5, '其他项目', 0, 1),
     (6, '其他项目-1', 5, 2),
     # (7, '登录接口', 2, 3),
     # (8, '其他接口', 1, 2),
     (11, '二级部门', 2, 3)
     )
# print(type(a))
list_test = []
child = []
father = []
new_li=[]

def test1():
    for i in a:
        child = []
        father = []
        for n in a:
            if i[0]==n[2]:
                father.append(i)
                child.append(n)
        if i in
        if child:
            # print(type(father))
            # print(type(new_li))
            new_li.append(father[0])
            # new_li.sort(key=father.index)
            new_li.append(child)
            list_test.append(new_li)
    print(str(list_test).decode("string-escape").decode("utf-8"))


a = test1()
