a={u'header': {u'msg': [u'\u672a\u77e5\u9519\u8bef'], u'code': u'1098', u'err': None, u'ret': u'F'}, u'ext': u'1098', u'data': None, u'extra': None}
print(str(a['header']['msg']).decode('utf-8'))