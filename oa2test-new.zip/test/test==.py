for i ,z in zip(range(4,0,-1),range(0,3)):
    print(i,z)