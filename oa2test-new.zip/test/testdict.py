a={}
# a['data']=[]
a['data']={}
a['data']["1"]=[1,2,3,4,]
a['data']["2"]=[1,2,3,4,]

# a['data']['1']=("aaa")
# # a['data'].append("aaa")
# a['data'].append("bbb")

# a['1']['0']='bbb'
# a['1']['1']='bbb'
print(a)