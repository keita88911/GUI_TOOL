class a():

    def b(self):
        a=2
        print(1)
        return a
    def F(self):
        c=a.b(self)
        print (c)
test=a()
test.F()