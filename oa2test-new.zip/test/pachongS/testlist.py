# -*- coding: UTF-8 -*-
import sys

reload(sys)
sys.setdefaultencoding('utf-8')
L =[['中国', 'a', 'b'],['asd,fa阿达']]



print  str(L).decode('string_escape')