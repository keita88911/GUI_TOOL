a=[]
b=None
a.append(b)
print(a)