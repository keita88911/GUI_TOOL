for a in range(0,10):
    for b in range(0,5):
        if a==b :
            print(a)