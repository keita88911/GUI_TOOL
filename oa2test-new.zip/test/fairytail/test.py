
# -*- coding=utf-8 -*-
a="ur"
# b=1
# print(a+'%d'+'%d',%(b for b in range(1,3),c for c in range(1,3))
# print(a+'%d'%(b for b in range(1,20)) )
# a1=[a+str(b) +str(c)+str(d)for b in range(0,10) for c in range(0,10)for d in range(1)]
# print(a1)

# base_url = 'https://movie.douban.com/top250?start='
# # 构造所有ｕｒｌ
# url_list = [a+str(num) for num in range(0, 225 + 1, 25)]
# ur2=[str(a1) for a1 in url_list]
# ur2.insert(1,2)
# print(len(ur2))
# print(type(ur2))
# print(ur2)
# test = []
# for n in range(0, 2):
#     for t in range(0, ):
#         for i in range(0, 10):
#             for m in range(0, 10):
#
#                 test.append(str(n)+str(t)+str(i)+str(m))
# print(test)
a=[1,2,3]
b=[4,5,6]
a1=[]
for a1 ,b1 in zip(a , b):
    print(a1)
    print(b1)