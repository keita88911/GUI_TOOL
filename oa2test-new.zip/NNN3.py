# -*- coding: UTF-8 -*-
import rdexcel
import requests
import json
import weblogin
import  MySQLdb
import getsql
import api
import sys

# default_encoding = 'utf-8'
# if sys.getdefaultencoding() != default_encoding:
#     reload(sys)
#     sys.setdefaultencoding(default_encoding)
class CheLiangPingGuBaoGao():
    @classmethod
    def CheLiangPingGuBG(self):
        try:
            print("阿打算大 "):
        :
            print(1)

a=CheLiangPingGuBaoGao.CheLiangPingGuBG()