# -*- coding: UTF-8 -*-
import os
class Dirpath():
    @classmethod
    def dir(self):
        dir=os.path.dirname(__file__)
        # print(dir)
        return dir
# a=Dirpath.dir()


